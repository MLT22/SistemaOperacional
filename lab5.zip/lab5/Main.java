public class Main {
    // capacidade do buffer do problema
    public static final int CAPACITY = 10; // Mantive, mas como só utilzamos o mutex não foi necessário

    /*
    NOME: João Carlos de Oliveira Serrano - RA: 23.10205-5 
    NOME: Gustavo Fernandes Arantes Maluta - RA: 23.10050-8 

    */
    public static void main(String[] args) {
       Account conta = new Account(1000);
       Client c1 = new Client("Gustavo", conta);
       Client c2 = new Client("João", conta);
       Client c3 = new Client("Gabriel", conta);
       Client c4 = new Client("Leo", conta);

        c1.run();
        c2.run();
        c3.run();
        c4.run();

    }

}
